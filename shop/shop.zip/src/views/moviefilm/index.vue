<template>
  <div class="box">
    <MoviePageTop></MoviePageTop>
    这里是影院详情
  </div>
</template>

<script>
import MoviePageTop from '@/components/pages/moviePage/moviePageTop'
export default {
  data () {
    return {

    }
  },
  components: {
    MoviePageTop
  }
}
</script>

<style>
</style>
