<template>
  <div>
    <Tab></Tab>
    <router-view />
  </div>
</template>

<script>
import Tab from '../../components/pages/Home/nav'
export default {
  components: {
    Tab
  }
}
</script>

<style>
</style>
