<template>
  <div>
    <Upcoming />
  </div>
</template>

<script>
import Upcoming from "@/components/pages/Home/Upcoming"
export default {
  components: {
    Upcoming
  }
}
</script>

<style lang="scss" scoped>
$sc: 25;
</style>

