<template>
  <div>
    <My />
    <Footer />
  </div>
</template>

<script>
import Footer from '@/components/common/Footer'
import My from '@/components/pages/user/My'
export default {
  data () {
    return {

    }
  },
  components: {
    Footer,
    My
  }
}
</script>

<style>
</style>
